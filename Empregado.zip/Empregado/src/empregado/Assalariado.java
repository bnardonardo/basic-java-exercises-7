package empregado;

public class Assalariado extends Empregado{
    public double Salario;
    
    public Assalariado (String nome, int cpf, int dataContratacao, double Salario){
        super(nome, cpf, dataContratacao);
        this.Salario=Salario;
    }
    
    public Assalariado (double Salario){
        super();
        this.Salario=Salario;
    }
    
    public double getSalario(){
    return Salario;
    }
    
    public void setSalario(){
        this.Salario=Salario;
    }
    
    public double rendimentos(){
        return Salario;
    }
    
        @Override
    public String toString (){
        return String.format ("%s, tem rendimentos de %.2f e pela tabela deve reduzir %.4f", super.toString(), rendimentos(), super.irpf()); 
    }
}