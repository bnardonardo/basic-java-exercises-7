package empregado;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        
        Assalariado P=new Assalariado ("José", 12345678, 2010, 3750.64);
        System.out.println (P);
        
        Comissionado P2=new Comissionado ("João", 32145678, 2019, 5050.00);
        System.out.println (P2);

        AssalariadoComissionado P3=new AssalariadoComissionado ("Maria", 12346578, 2008, 2750.84, 1100.90);
        System.out.println (P3);
    }
    
}
