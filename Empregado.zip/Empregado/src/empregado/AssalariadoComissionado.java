package empregado;

public class AssalariadoComissionado extends Comissionado {
     public double Salario;
    
    public AssalariadoComissionado (String nome, int cpf, int dataContratacao, double TotalVendas, double Salario){
        super(nome, cpf, dataContratacao, TotalVendas);
        this.Salario=Salario;
    }
    
    public double getSalario(){
        return Salario;
    }
    
    public void setSalario(){
        this.Salario=Salario;
    }
    
    public double rendimentos(){
         return Salario+(TotalVendas/10);
    }
    
        @Override
    public String toString (){
        return String.format ("%s, tem rendimentos de %.2f e pela tabela deve reduzir %.4f", super.toString(), rendimentos(), super.irpf()); 
    }
}
