package empregado;

public abstract class Empregado {
    public String nome;
    public int cpf;
    public int dataContratacao;
    
    public Empregado(String nome, int cpf, int dataContratacao){
        this.nome=nome;
        this.cpf=cpf;
        this.dataContratacao=dataContratacao;
    } 
    
    public Empregado(){
        
    }
     
    public String getNome(){
        return nome;
    }
    
    public void setNome(){
        this.nome=nome;
    }
    
    public int getCPF(){
        return cpf;
    }
    public void setCPF(){
        this.cpf=cpf;
    }
    
    public int getData(){
        return dataContratacao;
    }
    public void setData(){
        this.dataContratacao=dataContratacao;
    }
    
    public abstract double rendimentos();
    
    public double irpf(){
        if (rendimentos() <= 2026.65){
            return 142.80;
            
        } else if(rendimentos()>2026.65 && rendimentos()<=3751.05){
            return 354.80;
            
        }else if(rendimentos()>3751.05 && rendimentos()<=4664.68){
            return 636.13;
            
        }else /*if (rendimentos()>4664.68){*/
            return 869.36;
    }
    
    @Override
    public String toString (){
        return String.format ("O(a) empregado(a) %s portador(a) do cpf %d contratado(a) em %d", nome, cpf, dataContratacao); 
    }
}
