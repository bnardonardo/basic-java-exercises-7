package figurasplanas;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        
        Quadrado Q=new Quadrado ("Quadrado",2);
        Retangulo R=new Retangulo ("Retangulo",2,3);
        Circulo C=new Circulo ("Circulo",4);
        Triangulo T=new Triangulo ("Triangulo", 2,3);
        
        System.out.printf ("%s\n\n%s\n\n%s\n\n%s\n", Q, C, R, T);
        
    }
    
}
