package figurasplanas;

public class Circulo extends FigPlanas{
    private double raio;
    
    public Circulo (String nome, double raio ){
        super(nome);
        this.raio=(raio<=0?1:raio);
    }
    
    public double getRaio(){
        return raio;
    }
    
    public void setRaio(double raio){
         this.raio=(raio<=0?1:raio);
    }
    
    @Override
    public double area(){
         return raio*raio*Math.PI;
    }
    
    @Override
    public String dados(){
         return String.format ("Raio: %.2f", raio);
    }

    
}
