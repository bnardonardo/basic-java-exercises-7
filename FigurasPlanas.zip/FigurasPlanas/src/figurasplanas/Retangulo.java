package figurasplanas;

public class Retangulo extends Quadrado{
    private double comprimento;
    
    public Retangulo (String nome, double lado, double comprimento){
        super(nome, lado);
        this.comprimento=(comprimento<=0?1:comprimento);
    }
    
    public double getComp(){
        return comprimento;
    }
    
    public void setComp(double comprimento){
         this.comprimento=(comprimento<=0?1:comprimento);
    }
    
    @Override
    public double area (){
         return super.getLado()*comprimento ;
    }
    
    @Override
    public String dados(){
         return String.format ("%s\nComprimento: %.2f", super.dados(), comprimento);
    }
}