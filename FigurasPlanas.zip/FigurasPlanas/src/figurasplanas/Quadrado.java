package figurasplanas;

public class Quadrado extends FigPlanas {
    private double lado; 
    
    public Quadrado (String nome, double lado){
        super(nome);
        this.lado=(lado<=0?1:lado);
    }
    
    public double getLado(){
        return lado;
    }
    
    public void setLado(double lado){
         if(lado<=0) this.lado=1;
        else this.lado=lado;
    }
    
    @Override
    public double area (){
         return lado*lado;
    }
    
    @Override
    public String dados(){
         return String.format ("Lado: %.2f", lado);
    }
}
